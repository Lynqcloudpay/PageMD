const { Pool } = require('pg');
require('dotenv').config();

const config = process.env.DATABASE_URL
    ? { connectionString: process.env.DATABASE_URL }
    : {
        host: process.env.DB_HOST || 'localhost',
        port: process.env.DB_PORT || 5432,
        database: process.env.DB_NAME || 'paper_emr',
        user: process.env.DB_USER || 'postgres',
        password: process.env.DB_PASSWORD || 'postgres',
    };

const pool = new Pool(config);

async function migrate() {
    const client = await pool.connect();

    try {
        console.log('Starting patients table schema update...');
        await client.query('BEGIN');

        // Add missing columns to patients table
        await client.query(`
      ALTER TABLE patients
      ADD COLUMN IF NOT EXISTS middle_name VARCHAR(100),
      ADD COLUMN IF NOT EXISTS name_suffix VARCHAR(20),
      ADD COLUMN IF NOT EXISTS preferred_name VARCHAR(100),
      ADD COLUMN IF NOT EXISTS gender VARCHAR(50),
      ADD COLUMN IF NOT EXISTS race VARCHAR(50),
      ADD COLUMN IF NOT EXISTS ethnicity VARCHAR(50),
      ADD COLUMN IF NOT EXISTS marital_status VARCHAR(50),

      ADD COLUMN IF NOT EXISTS phone_secondary VARCHAR(20),
      ADD COLUMN IF NOT EXISTS phone_cell VARCHAR(20),
      ADD COLUMN IF NOT EXISTS phone_work VARCHAR(20),
      ADD COLUMN IF NOT EXISTS phone_preferred VARCHAR(20),
      ADD COLUMN IF NOT EXISTS email_secondary VARCHAR(255),
      ADD COLUMN IF NOT EXISTS preferred_language VARCHAR(50),
      ADD COLUMN IF NOT EXISTS interpreter_needed BOOLEAN DEFAULT false,
      ADD COLUMN IF NOT EXISTS communication_preference VARCHAR(50),
      ADD COLUMN IF NOT EXISTS consent_to_text BOOLEAN DEFAULT false,
      ADD COLUMN IF NOT EXISTS consent_to_email BOOLEAN DEFAULT false,

      ADD COLUMN IF NOT EXISTS country VARCHAR(100) DEFAULT 'United States',
      ADD COLUMN IF NOT EXISTS address_type VARCHAR(50) DEFAULT 'Home',

      ADD COLUMN IF NOT EXISTS employment_status VARCHAR(50),
      ADD COLUMN IF NOT EXISTS occupation VARCHAR(255),
      ADD COLUMN IF NOT EXISTS employer_name VARCHAR(255),

      ADD COLUMN IF NOT EXISTS emergency_contact_name VARCHAR(255),
      ADD COLUMN IF NOT EXISTS emergency_contact_phone VARCHAR(20),
      ADD COLUMN IF NOT EXISTS emergency_contact_relationship VARCHAR(100),
      ADD COLUMN IF NOT EXISTS emergency_contact_address TEXT,
      ADD COLUMN IF NOT EXISTS emergency_contact_2_name VARCHAR(255),
      ADD COLUMN IF NOT EXISTS emergency_contact_2_phone VARCHAR(20),
      ADD COLUMN IF NOT EXISTS emergency_contact_2_relationship VARCHAR(100),

      ADD COLUMN IF NOT EXISTS insurance_group_number VARCHAR(100),
      ADD COLUMN IF NOT EXISTS insurance_plan_name VARCHAR(255),
      ADD COLUMN IF NOT EXISTS insurance_plan_type VARCHAR(100),
      ADD COLUMN IF NOT EXISTS insurance_subscriber_name VARCHAR(255),
      ADD COLUMN IF NOT EXISTS insurance_subscriber_dob DATE,
      ADD COLUMN IF NOT EXISTS insurance_subscriber_relationship VARCHAR(50),
      ADD COLUMN IF NOT EXISTS insurance_copay VARCHAR(50),
      ADD COLUMN IF NOT EXISTS insurance_effective_date DATE,
      ADD COLUMN IF NOT EXISTS insurance_expiry_date DATE,
      ADD COLUMN IF NOT EXISTS insurance_notes TEXT,

      ADD COLUMN IF NOT EXISTS pharmacy_npi VARCHAR(20),
      ADD COLUMN IF NOT EXISTS pharmacy_fax VARCHAR(20),
      ADD COLUMN IF NOT EXISTS pharmacy_preferred BOOLEAN DEFAULT false,

      ADD COLUMN IF NOT EXISTS referral_source VARCHAR(255),
      ADD COLUMN IF NOT EXISTS smoking_status VARCHAR(50),
      ADD COLUMN IF NOT EXISTS alcohol_use VARCHAR(50),
      ADD COLUMN IF NOT EXISTS allergies_known BOOLEAN DEFAULT false,
      ADD COLUMN IF NOT EXISTS notes TEXT,
      ADD COLUMN IF NOT EXISTS deceased BOOLEAN DEFAULT false,
      ADD COLUMN IF NOT EXISTS deceased_date DATE;
    `);

        // Ensure encryption_metadata column exists (it should, but just in case of fresh usage)
        await client.query(`
        ALTER TABLE patients 
        ADD COLUMN IF NOT EXISTS encryption_metadata TEXT;
    `);

        // Also ensure clinic_id exists for multi-tenant keys
        await client.query(`
        ALTER TABLE patients 
        ADD COLUMN IF NOT EXISTS clinic_id UUID;
    `);

        await client.query('COMMIT');
        console.log('✅ Patients table schema update completed successfully');
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ Migration failed:', error);
        process.exit(1);
    } finally {
        client.release();
        await pool.end();
    }
}

migrate().catch(err => {
    console.error(err);
    process.exit(1);
});

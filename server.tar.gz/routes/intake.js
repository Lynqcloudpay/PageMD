const express = require('express');
const crypto = require('crypto');
const pool = require('../db');
const { authenticate, logAudit } = require('../middleware/auth');
const emailService = require('../services/emailService');
const path = require('path');
const fs = require('fs');
const pdfService = require('../services/pdfService');

const router = express.Router();

/**
 * Helper: Generate readable Resume Code (8 chars)
 */
function generateResumeCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // No O, 0, I, 1
    let code = '';
    for (let i = 0; i < 8; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
}

function hashToken(token) {
    return crypto.createHash('sha256').update(token.toUpperCase()).digest('hex');
}

function normalizePhone(phone) {
    if (!phone) return '';
    return phone.replace(/\D/g, '');
}

function normalizeName(name) {
    if (!name) return '';
    return name.trim().toLowerCase();
}

/**
 * Helper: Log Audit Event
 */
async function logIntakeAudit(client, tenantId, actorType, actorId, action, objectType, objectId, req) {
    const ip = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    const userAgent = req.headers['user-agent'];
    await client.query(`
        INSERT INTO audit_events (tenant_id, actor_type, actor_id, action, object_type, object_id, ip, user_agent)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    `, [tenantId, actorType, actorId, action, objectType, objectId, ip, userAgent]);
}

// --- STAFF ENDPOINTS ---

/**
 * GET /sessions
 * List submissions for staff review
 */
router.get('/sessions', authenticate, async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT id, status, prefill_json, submitted_at, created_at, updated_at, patient_id
            FROM intake_sessions
            WHERE tenant_id = $1
            ORDER BY created_at DESC
        `, [req.clinic.id]);
        res.json(result.rows);
    } catch (error) {
        console.error('[Intake] List failed:', error);
        res.status(500).json({ error: 'Failed' });
    }
});

/**
 * GET /stats
 */
router.get('/stats', authenticate, async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT COUNT(*) as count
            FROM intake_sessions
            WHERE tenant_id = $1 AND status = 'SUBMITTED'
        `, [req.clinic.id]);
        res.json({ pendingCount: parseInt(result.rows[0].count) });
    } catch (error) {
        console.error('[Intake] Stats failed:', error);
        res.status(500).json({ error: 'Failed' });
    }
});

/**
 * GET /session/:id
 */
router.get('/session/:id', authenticate, async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT * FROM intake_sessions
            WHERE id = $1 AND tenant_id = $2
        `, [req.params.id, req.clinic.id]);

        if (result.rows.length === 0) return res.status(404).json({ error: 'Session not found' });
        res.json(result.rows[0]);
    } catch (error) {
        console.error('[Intake] Get failed:', error);
        res.status(500).json({ error: 'Failed' });
    }
});

/**
 * DELETE /session/:id - Delete an intake session
 */
router.delete('/session/:id', authenticate, async (req, res) => {
    try {
        const result = await pool.query(`
            DELETE FROM intake_sessions
            WHERE id = $1 AND tenant_id = $2
            RETURNING id
        `, [req.params.id, req.clinic.id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Session not found' });
        }

        await logIntakeAudit(pool, req.clinic.id, 'staff', req.user.id, 'delete_session', 'intake_sessions', req.params.id, req);
        res.json({ success: true });
    } catch (error) {
        console.error('[Intake] Delete failed:', error);
        res.status(500).json({ error: 'Failed to delete session' });
    }
});

/**
 * POST /session/:id/regenerate-code - Generate a new resume code for a patient
 */
router.post('/session/:id/regenerate-code', authenticate, async (req, res) => {
    try {
        const { id } = req.params;

        const checkRes = await pool.query(`
            SELECT id, status FROM intake_sessions
            WHERE id = $1 AND tenant_id = $2
        `, [id, req.clinic.id]);

        if (checkRes.rows.length === 0) {
            return res.status(404).json({ error: 'Session not found' });
        }

        const session = checkRes.rows[0];
        if (session.status === 'APPROVED' || session.status === 'SUBMITTED') {
            return res.status(400).json({ error: 'Cannot regenerate code for completed sessions' });
        }

        const newResumeCode = generateResumeCode();
        const newHash = hashToken(newResumeCode);
        const newExpiry = new Date();
        newExpiry.setDate(newExpiry.getDate() + 7);

        await pool.query(`
            UPDATE intake_sessions
            SET resume_code_hash = $1, expires_at = $2, updated_at = CURRENT_TIMESTAMP
            WHERE id = $3
        `, [newHash, newExpiry, id]);

        await logIntakeAudit(pool, req.clinic.id, 'staff', req.user.id, 'regenerate_code', 'intake_sessions', id, req);

        res.json({
            success: true,
            resumeCode: newResumeCode,
            expiresAt: newExpiry
        });
    } catch (error) {
        console.error('[Intake] Regenerate code failed:', error);
        res.status(500).json({ error: 'Failed to regenerate code' });
    }
});

/**
 * POST /clear-rate-limits - Clear lookup rate limits (Staff only)
 */
router.post('/clear-rate-limits', authenticate, async (req, res) => {
    try {
        const { lastName, dob } = req.body;
        if (lastName && dob) {
            const lastNameNorm = normalizeName(lastName);
            const key = `${lastNameNorm}:${dob}`;
            lookupRateLimit.delete(key);
            console.log(`[Intake] Rate limit cleared for specific patient: ${key}`);
            await logIntakeAudit(pool, req.clinic.id, 'staff', req.user.id, 'clear_rate_limit_individual', 'system', key, req);
            return res.json({ success: true, message: `Rate limit cleared for patient ${lastName}` });
        }

        lookupRateLimit.clear();
        await logIntakeAudit(pool, req.clinic.id, 'staff', req.user.id, 'clear_rate_limits_all', 'system', null, req);
        res.json({ success: true, message: 'All intake lookup rate limits cleared' });
    } catch (e) {
        console.error('[Intake] Clear rate limits failed:', e);
        res.status(500).json({ error: 'Failed to clear rate limits' });
    }
});

/**
 * GET /public/clinic-info - Get clinic info and intake templates
 */
router.get('/public/clinic-info', async (req, res) => {
    try {
        if (!req.clinic?.id) {
            return res.status(400).json({ error: 'Clinic not specified' });
        }

        // Fetch clinic settings/templates for the public intake form
        const settingsRes = await pool.query('SELECT key, value FROM intake_settings');
        const templates = {};
        settingsRes.rows.forEach(r => { templates[r.key] = r.value; });

        // Fetch branding from tenant-specific practice_settings for most up-to-date info
        const practiceRes = await pool.query('SELECT practice_name, logo_url, address_line1, address_line2, city, state, zip, phone FROM practice_settings LIMIT 1');
        const p = practiceRes.rows[0] || {};

        res.json({
            name: p.practice_name || req.clinic.name || 'Medical Practice',
            slug: req.clinic.slug,
            logoUrl: p.logo_url || req.clinic.logo_url || null,
            address: p.address_line1
                ? [p.address_line1, p.address_line2, `${p.city || ''} ${p.state || ''} ${p.zip || ''}`.trim()].filter(Boolean).join('\n')
                : req.clinic.address,
            phone: p.phone || req.clinic.phone || null,
            templates
        });
    } catch (error) {
        console.error('[Intake] Clinic info failed:', error);
        res.status(500).json({ error: 'Failed to get clinic info' });
    }
});

/**
 * POST /session/:id/approve
 */
router.post('/session/:id/approve', authenticate, async (req, res) => {
    const patientEncryptionService = require('../services/patientEncryptionService');
    try {
        const { id } = req.params;
        const { linkToPatientId } = req.body;

        const subRes = await pool.query(`
            SELECT * FROM intake_sessions
            WHERE id = $1 AND tenant_id = $2
        `, [id, req.clinic.id]);

        if (subRes.rows.length === 0) return res.status(404).json({ error: 'Session not found' });
        const session = subRes.rows[0];

        if (session.status === 'APPROVED') {
            return res.status(400).json({ error: 'Already approved and locked.' });
        }
        const data = session.data_json;

        let targetPatientId = linkToPatientId;

        if (!targetPatientId) {
            const finalMRN = data.mrn || String(Math.floor(100000 + Math.random() * 900000));

            // Map sex value from intake form to database constraint format
            const mapSex = (val) => {
                if (!val) return null;
                const lower = val.toLowerCase();
                if (lower === 'male' || lower === 'm') return 'M';
                if (lower === 'female' || lower === 'f') return 'F';
                return 'Other';
            };

            const patientData = {
                mrn: finalMRN,
                first_name: data.firstName || session.prefill_json.firstName,
                last_name: data.lastName || session.prefill_json.lastName,
                dob: data.dob || session.prefill_json.dob,
                sex: mapSex(data.sex),
                preferred_language: data.preferredLanguage,
                phone: data.phone || session.prefill_json.phone,
                phone_secondary: data.phoneSecondary,
                email: data.email,
                address_line1: data.addressLine1,
                address_line2: data.addressLine2,
                city: data.city,
                state: data.state,
                zip: data.zip,
                communication_preference: data.preferredContactMethod,
                emergency_contact_name: data.ecName,
                emergency_contact_phone: data.ecPhone,
                emergency_contact_relationship: data.ecRelationship,
                insurance_provider: data.primaryInsuranceCarrier || data.primary_insurance_carrier,
                insurance_id: data.primaryMemberId || data.primary_member_id,
                insurance_group_number: data.primaryGroupNumber || data.primary_group_number,
                insurance_subscriber_name: data.primaryPolicyholderName || data.primary_policyholder_name,
                insurance_subscriber_dob: data.primaryPolicyholderDob || data.primary_policyholder_dob,
                occupation: data.occupation,
                clinic_id: req.clinic.id,
                phone_normalized: (data.phone || session.prefill_json.phone || '').replace(/\D/g, '')
            };

            const encrypted = await patientEncryptionService.preparePatientForStorage(patientData);
            const fields = Object.keys(encrypted).filter(k => k !== 'encryption_metadata');
            const values = fields.map(f => encrypted[f]);
            fields.push('encryption_metadata');
            values.push(JSON.stringify(encrypted.encryption_metadata));

            const placeholders = values.map((_, i) => `$${i + 1}`).join(', ');
            const patientRes = await pool.query(
                `INSERT INTO patients (${fields.join(', ')}) VALUES (${placeholders}) RETURNING id`,
                values
            );
            targetPatientId = patientRes.rows[0].id;
        } else {
            // If linking to an existing patient, update their demographic info
            const mapSex = (val) => {
                if (!val) return null;
                const lower = val.toLowerCase();
                if (lower === 'male' || lower === 'm') return 'M';
                if (lower === 'female' || lower === 'f') return 'F';
                return 'Other';
            };

            const patientData = {
                first_name: data.firstName || session.prefill_json.firstName,
                last_name: data.lastName || session.prefill_json.lastName,
                dob: data.dob || session.prefill_json.dob,
                sex: mapSex(data.sex),
                preferred_language: data.preferredLanguage,
                phone: data.phone || session.prefill_json.phone,
                phone_secondary: data.phoneSecondary,
                email: data.email,
                address_line1: data.addressLine1,
                address_line2: data.addressLine2,
                city: data.city,
                state: data.state,
                zip: data.zip,
                communication_preference: data.preferredContactMethod,
                emergency_contact_name: data.ecName,
                emergency_contact_phone: data.ecPhone,
                emergency_contact_relationship: data.ecRelationship,
                insurance_provider: data.primaryInsuranceCarrier || data.primary_insurance_carrier,
                insurance_id: data.primaryMemberId || data.primary_member_id,
                insurance_group_number: data.primaryGroupNumber || data.primary_group_number,
                insurance_subscriber_name: data.primaryPolicyholderName || data.primary_policyholder_name,
                insurance_subscriber_dob: data.primaryPolicyholderDob || data.primary_policyholder_dob,
                occupation: data.occupation,
                phone_normalized: (data.phone || session.prefill_json.phone || '').replace(/\D/g, '')
            };

            const encrypted = await patientEncryptionService.preparePatientForStorage(patientData);
            const fields = Object.keys(encrypted).filter(k => k !== 'encryption_metadata');
            const setClause = fields.map((f, i) => `${f} = $${i + 1}`).join(', ');
            const values = fields.map(f => encrypted[f]);

            // Add metadata
            values.push(JSON.stringify(encrypted.encryption_metadata));
            values.push(targetPatientId);
            values.push(req.clinic.id);

            await pool.query(
                `UPDATE patients SET ${setClause}, encryption_metadata = $${values.length - 2} WHERE id = $${values.length - 1} AND clinic_id = $${values.length}`,
                values
            );
        }

        // Handle Clinical History Mapping (Sync for both new and linked patients)
        // 1. Allergies
        if (data.allergyList && data.allergyList.length > 0) {
            for (const a of data.allergyList) {
                const allergenName = a.allergen || a.name;
                const existing = await pool.query('SELECT 1 FROM allergies WHERE patient_id = $1 AND allergen = $2', [targetPatientId, allergenName]);
                if (existing.rows.length === 0) {
                    await pool.query('INSERT INTO allergies (patient_id, allergen, reaction, severity) VALUES ($1, $2, $3, $4)', [targetPatientId, allergenName, a.reaction, a.severity]);
                }
            }
        }

        // 2. Medications
        if (data.medsList && data.medsList.length > 0) {
            for (const m of data.medsList) {
                const medName = m.name;
                const existing = await pool.query('SELECT 1 FROM medications WHERE patient_id = $1 AND medication_name = $2', [targetPatientId, medName]);
                if (existing.rows.length === 0) {
                    await pool.query('INSERT INTO medications (patient_id, medication_name, dosage, frequency) VALUES ($1, $2, $3, $4)', [targetPatientId, medName, m.dose, m.frequency]);
                }
            }
        }

        // 3. Past Medical History (populate problems)
        if (data.pmhConditions && data.pmhConditions.length > 0) {
            for (const condition of data.pmhConditions) {
                const existing = await pool.query('SELECT 1 FROM problems WHERE patient_id = $1 AND problem_name = $2', [targetPatientId, condition]);
                if (existing.rows.length === 0) {
                    await pool.query('INSERT INTO problems (patient_id, problem_name, status) VALUES ($1, $2, $3)', [targetPatientId, condition, 'active']);
                }
            }
        }
        if (data.pmhOtherText) {
            const existing = await pool.query('SELECT 1 FROM problems WHERE patient_id = $1 AND problem_name = $2', [targetPatientId, data.pmhOtherText]);
            if (existing.rows.length === 0) {
                await pool.query('INSERT INTO problems (patient_id, problem_name, status) VALUES ($1, $2, $3)', [targetPatientId, data.pmhOtherText, 'active']);
            }
        }

        // 4. Family History
        const fhx = [];
        if (data.fhxHeartDisease) fhx.push('Heart Disease');
        if (data.fhxDiabetes) fhx.push('Diabetes');
        if (data.fhxCancer) fhx.push('Cancer');
        if (data.fhxStroke) fhx.push('Stroke');
        if (data.fhxOtherText) fhx.push(`Other: ${data.fhxOtherText}`);

        for (const f of fhx) {
            const existing = await pool.query('SELECT 1 FROM family_history WHERE patient_id = $1 AND condition = $2', [targetPatientId, f]);
            if (existing.rows.length === 0) {
                await pool.query('INSERT INTO family_history (patient_id, condition, relationship) VALUES ($1, $2, $3)', [targetPatientId, f, 'Family']);
            }
        }

        // 5. Social History
        if (data.tobaccoUse || data.alcoholUse || data.recreationalDrugUse || data.occupation) {
            const existing = await pool.query('SELECT id FROM social_history WHERE patient_id = $1', [targetPatientId]);
            if (existing.rows.length > 0) {
                await pool.query(`
                    UPDATE social_history SET
                        smoking_status = COALESCE($2, smoking_status),
                        alcohol_use = COALESCE($3, alcohol_use),
                        occupation = COALESCE($4, occupation),
                        drug_use = COALESCE($5, drug_use)
                    WHERE patient_id = $1
                `, [targetPatientId, data.tobaccoUse || null, data.alcoholUse || null, data.occupation || null, data.recreationalDrugUse || null]);
            } else {
                await pool.query(`
                    INSERT INTO social_history (patient_id, smoking_status, alcohol_use, occupation, drug_use)
                    VALUES ($1, $2, $3, $4, $5)
                `, [targetPatientId, data.tobaccoUse || null, data.alcoholUse || null, data.occupation || null, data.recreationalDrugUse || null]);
            }
        }

        await pool.query(`UPDATE intake_sessions SET status = 'APPROVED', patient_id = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2`, [targetPatientId, id]);

        // --- PDF Legal Packet Generation ---
        try {
            const settingsRes = await pool.query('SELECT key, value FROM intake_settings WHERE category = $1', ['legal']);
            const templates = {};
            settingsRes.rows.forEach(r => templates[r.key] = r.value);

            const practiceRes = await pool.query('SELECT practice_name, logo_url, address_line1, address_line2, city, state, zip, phone, email FROM practice_settings LIMIT 1');
            const p = practiceRes.rows[0] || {};
            const clinicData = {
                name: p.practice_name || req.clinic.name,
                address: [p.address_line1, p.address_line2, `${p.city || ''} ${p.state || ''} ${p.zip || ''}`.trim()].filter(Boolean).join('\n'),
                phone: p.phone || req.clinic.phone,
                email: p.email || req.clinic.email
            };

            const isSpanish = data.language === 'es';
            const forms = [
                { key: 'consentHIPAA', label: isSpanish ? 'Aviso de Privacidad (HIPAA)' : 'HIPAA Notice Acknowledgement', policy: isSpanish ? templates.hipaa_notice_es : templates.hipaa_notice },
                { key: 'consentTreat', label: isSpanish ? 'Consentimiento para Tratamiento' : 'Consent to Medical Treatment', policy: isSpanish ? templates.consent_to_treat_es : templates.consent_to_treat },
                { key: 'consentAOB', label: isSpanish ? 'Asignación de Beneficios' : 'Assignment of Benefits', policy: isSpanish ? templates.assignment_of_benefits_es : templates.assignment_of_benefits },
                { key: 'consentROI', label: isSpanish ? 'Autorización para Divulgar Información' : 'Authorization to Release Information', policy: isSpanish ? templates.release_of_information_es : templates.release_of_information }
            ].map(f => {
                let processed = f.policy || '';
                processed = processed
                    .replace(/{CLINIC_NAME}/g, clinicData.name)
                    .replace(/{CLINIC_ADDRESS}/g, clinicData.address)
                    .replace(/{CLINIC_PHONE}/g, clinicData.phone)
                    .replace(/{PRIVACY_EMAIL}/g, clinicData.email || 'privacy@pagemd.com')
                    .replace(/{EFFECTIVE_DATE}/g, new Date(session.submitted_at || Date.now()).toLocaleDateString(isSpanish ? 'es-US' : 'en-US'))
                    .replace(/{ROI_LIST}/g, (data.roiPeople || []).map(p => `${p.name} (${p.relationship})`).join(', ') || (isSpanish ? 'NINGUNO LISTADO' : 'NONE LISTED'));
                return { ...f, processedPolicy: processed };
            });

            const pdfBuffer = await pdfService.generateIntakeLegalPDF({
                clinic: clinicData,
                session,
                patientId: targetPatientId,
                signerName: data.signature,
                ip: session.ip_address || 'N/A',
                userAgent: session.user_agent || 'N/A',
                forms,
                language: data.language
            });

            const filename = `intake_legal_${id}_${Date.now()}.pdf`;
            const uploadDir = process.env.UPLOAD_DIR || './uploads';
            if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
            const filePath = path.join(uploadDir, filename);
            fs.writeFileSync(filePath, pdfBuffer);

            const urlPath = `/uploads/${filename}`;
            await pool.query(`
                INSERT INTO documents (patient_id, uploader_id, doc_type, filename, file_path, mime_type, file_size, tags)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            `, [targetPatientId, req.user.id, 'other', 'Intake Legal Packet.pdf', urlPath, 'application/pdf', pdfBuffer.length, ['legal', 'consent', 'intake', 'hipaa']]);

        } catch (pdfErr) {
            console.error('[Intake] PDF Packet generation failed:', pdfErr);
        }

        await pool.query(`
            UPDATE inbox_items SET 
                status = 'completed', 
                completed_at = CURRENT_TIMESTAMP, 
                completed_by = $1,
                patient_id = $2
            WHERE reference_id = $3 AND type = 'intake_registration'
        `, [req.user.id, targetPatientId, id]);

        await logIntakeAudit(pool, req.clinic.id, 'staff', req.user.id, 'approve', 'intake_sessions', id, req);

        res.json({ success: true, patientId: targetPatientId });
    } catch (error) {
        console.error('[Intake] Approval failed:', error);
        res.status(500).json({ error: 'System error' });
    }
});

/**
 * POST /session/:id/needs-edits
 */
router.post('/session/:id/needs-edits', authenticate, async (req, res) => {
    try {
        const { id } = req.params;
        const { note } = req.body;

        if (!note) return res.status(400).json({ error: 'Note required' });

        const result = await pool.query(`
            UPDATE intake_sessions 
            SET status = 'NEEDS_EDITS', 
                review_notes = review_notes || $1::jsonb,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = $2 AND tenant_id = $3
            RETURNING id
        `, [JSON.stringify([{ note, author: `${req.user.first_name} ${req.user.last_name}`, created_at: new Date() }]), id, req.clinic.id]);

        if (result.rows.length === 0) return res.status(404).json({ error: 'Not found' });

        await pool.query(`
            UPDATE inbox_items SET status = 'NeedsEdits', updated_at = CURRENT_TIMESTAMP
            WHERE reference_id = $1 AND reference_table = 'intake_sessions'
        `, [id]);

        await logIntakeAudit(pool, req.clinic.id, 'staff', req.user.id, 'needs_edits', 'intake_sessions', id, req);

        res.json({ success: true });
    } catch (error) {
        console.error('[Intake] Needs Edits failed:', error);
        res.status(500).json({ error: 'System error' });
    }
});

/**
 * GET /session/:id/duplicates
 */
router.get('/session/:id/duplicates', authenticate, async (req, res) => {
    try {
        const { id } = req.params;
        const subRes = await pool.query('SELECT prefill_json FROM intake_sessions WHERE id = $1 AND tenant_id = $2', [id, req.clinic.id]);
        if (subRes.rows.length === 0) return res.status(404).json({ error: 'Not found' });

        const prefill = subRes.rows[0].prefill_json;
        const { firstName, lastName, dob, phone } = prefill;
        const phoneNorm = (phone || '').replace(/\D/g, '');

        // Use the patientEncryptionService to decrypt and search if needed, but for now 
        // we'll use the plaintext dob and phone_normalized which are already indexed.
        const dupRes = await pool.query(`
            SELECT id, first_name, last_name, dob, mrn 
            FROM patients 
            WHERE (
                (LOWER(first_name) LIKE LOWER($1) || '%' AND LOWER(last_name) LIKE LOWER($2) || '%' AND dob = $3)
                OR (phone_normalized = $4 AND phone_normalized <> '')
            )
            AND clinic_id = $5
            LIMIT 5
        `, [firstName, lastName, dob, phoneNorm, req.clinic.id]);

        const patientEncryptionService = require('../services/patientEncryptionService');
        const decrypted = await patientEncryptionService.decryptPatientsPHI(dupRes.rows);

        res.json(decrypted);
    } catch (error) {
        console.error('[Intake] Duplicate check failed:', error);
        res.status(500).json({ error: 'Failed' });
    }
});

// --- PUBLIC ENDPOINTS ---

/**
 * POST /public/start
 */
router.post('/public/start', async (req, res) => {
    try {
        const { firstName, lastName, dob, phone } = req.body;
        if (!firstName || !lastName || !dob || !phone) {
            return res.status(400).json({ error: 'Missing required start fields' });
        }

        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 7);

        const phoneNorm = normalizePhone(phone);
        const phoneLast4 = phoneNorm.slice(-4);
        const lastNameNorm = normalizeName(lastName);

        // Resume code is deprecated/removed in new flow, but column exists. Store empty/placeholder.
        const result = await pool.query(`
            INSERT INTO intake_sessions (
                tenant_id, resume_code_hash, expires_at, prefill_json, status,
                patient_first_name, patient_last_name, patient_last_name_normalized,
                patient_dob, patient_phone_normalized, patient_phone_last4
            ) VALUES ($1, $2, $3, $4, 'IN_PROGRESS', $5, $6, $7, $8, $9, $10)
            RETURNING id
        `, [
            req.clinic.id,
            '', // resume_code_hash
            expiresAt,
            { firstName, lastName, dob, phone },
            firstName,
            lastName,
            lastNameNorm,
            dob,
            phoneNorm,
            phoneLast4
        ]);

        const sessionId = result.rows[0].id;
        await logIntakeAudit(pool, req.clinic.id, 'patient', null, 'start', 'intake_sessions', sessionId, req);

        res.json({
            sessionId,
            expiresAt
        });
    } catch (error) {
        console.error('[Intake] Start failed:', error);
        res.status(500).json({ error: 'System error' });
    }
});

// Rate limiting for "Continue" lookups (simple in-memory instance-bound)
const lookupRateLimit = new Map();
function checkRateLimit(key) {
    const now = Date.now();
    const windowMs = 10 * 60 * 1000; // 10 minutes
    const max = 5;

    const data = lookupRateLimit.get(key) || { count: 0, resetAt: now + windowMs };
    if (now > data.resetAt) {
        data.count = 1;
        data.resetAt = now + windowMs;
    } else {
        data.count++;
    }
    lookupRateLimit.set(key, data);
    return data.count <= max;
}

/**
 * POST /public/continue
 * Search for existing sessions by details
 */
router.post('/public/continue', async (req, res) => {
    try {
        const { lastName, dob, phone } = req.body;
        if (!lastName || !dob || !phone) {
            return res.status(400).json({ error: 'Missing lookup details' });
        }

        const ip = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;
        if (!checkRateLimit(ip)) {
            return res.status(429).json({ error: 'Too many attempts. Please try again in 10 minutes.' });
        }

        const lastNameNorm = normalizeName(lastName);
        const phoneNorm = normalizePhone(phone);

        if (!checkRateLimit(`${lastNameNorm}:${dob}`)) {
            return res.status(429).json({ error: 'Too many attempts for this name/DOB combo.' });
        }

        const result = await pool.query(`
            SELECT id, patient_first_name, patient_last_name, patient_dob, patient_phone_normalized, status
            FROM intake_sessions
            WHERE tenant_id = $1
              AND patient_last_name_normalized = $2
              AND patient_dob = $3
              AND (patient_phone_normalized = $4 OR patient_phone_last4 = $5)
              AND status IN ('IN_PROGRESS', 'NEEDS_EDITS', 'SUBMITTED')
              AND expires_at > CURRENT_TIMESTAMP
            ORDER BY created_at DESC
        `, [req.clinic.id, lastNameNorm, dob, phoneNorm, phoneNorm.slice(-4)]);

        // Audit log the attempt
        await logIntakeAudit(pool, req.clinic.id, 'patient', null, 'continue_lookup', 'intake_sessions', null, req);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'No active or submitted registration found matching these details.' });
        }

        if (result.rows.length === 1) {
            const session = result.rows[0];
            // Fetch full prefill/data for the single match
            const fullRes = await pool.query('SELECT prefill_json, data_json, status, review_notes FROM intake_sessions WHERE id = $1', [session.id]);
            const full = fullRes.rows[0];

            return res.json({
                sessionId: session.id,
                prefill: full.prefill_json,
                data: full.data_json,
                status: full.status,
                reviewNotes: full.review_notes
            });
        }

        // Multiple matches: return masked candidates
        const candidates = result.rows.map(r => ({
            id: r.id,
            firstNameInitial: r.patient_first_name ? r.patient_first_name[0] : '?',
            lastName: r.patient_last_name,
            dob: r.patient_dob,
            maskedPhone: '***-***-' + (r.patient_phone_normalized || '').slice(-4)
        }));

        res.json({ candidates });
    } catch (error) {
        console.error('[Intake] Continue failed:', error);
        res.status(500).json({ error: 'System error' });
    }
});

/**
 * POST /public/session/:id
 * Fetch session details but requires patient verification details (Last Name, DOB, Phone)
 */
router.post('/public/session/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { lastName, dob, phone } = req.body;

        if (!lastName || !dob || !phone) {
            return res.status(400).json({ error: 'Missing verification details' });
        }

        const lastNameNorm = normalizeName(lastName);
        const phoneNorm = normalizePhone(phone);

        const result = await pool.query(`
            SELECT prefill_json, data_json, status, review_notes,
                   patient_last_name_normalized, patient_dob, patient_phone_normalized, patient_phone_last4
            FROM intake_sessions
            WHERE id = $1 AND tenant_id = $2
              AND expires_at > CURRENT_TIMESTAMP
        `, [id, req.clinic.id]);

        if (result.rows.length === 0) return res.status(404).json({ error: 'Session not found or expired' });
        const s = result.rows[0];

        // Verify details match
        const dbDob = s.patient_dob instanceof Date ? s.patient_dob.toISOString().split('T')[0] : String(s.patient_dob).split('T')[0];

        if (s.patient_last_name_normalized !== lastNameNorm ||
            dbDob !== dob ||
            (s.patient_phone_normalized !== phoneNorm && s.patient_phone_last4 !== phoneNorm)) {
            return res.status(401).json({ error: 'Verification failed' });
        }

        res.json({
            id,
            prefill_json: s.prefill_json,
            data_json: s.data_json,
            status: s.status,
            review_notes: s.review_notes
        });
    } catch (error) {
        console.error('[Intake] Public get session failed:', error);
        res.status(500).json({ error: 'System error' });
    }
});

/**
 * POST /public/resume
 */
router.post('/public/resume', async (req, res) => {
    try {
        const { resumeCode, dob } = req.body;
        if (!resumeCode || !dob) return res.status(400).json({ error: 'Missing credentials' });

        const hash = hashToken(resumeCode);

        const result = await pool.query(`
            SELECT * FROM intake_sessions
            WHERE resume_code_hash = $1 AND expires_at > CURRENT_TIMESTAMP
            AND tenant_id = $2
        `, [hash, req.clinic.id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Invalid or expired resume code' });
        }

        const session = result.rows[0];

        // DOB Verification (Security Step)
        if (session.prefill_json.dob !== dob) {
            // Simple rate limit could be added here
            return res.status(401).json({ error: 'Verification failed. Please check Date of Birth.' });
        }

        if (session.status === 'APPROVED') {
            return res.status(400).json({ error: 'This registration has already been approved. Please see front desk.' });
        }

        await logIntakeAudit(pool, req.clinic.id, 'patient', null, 'resume', 'intake_sessions', session.id, req);

        res.json({
            sessionId: session.id,
            status: session.status,
            prefill: session.prefill_json,
            data: session.data_json,
            reviewNotes: session.review_notes
        });
    } catch (error) {
        console.error('[Intake] Resume failed:', error);
        res.status(500).json({ error: 'System error' });
    }
});

/**
 * POST /public/save/:id
 */
router.post('/public/save/:id', async (req, res) => {
    try {
        const { data } = req.body;
        const result = await pool.query(`
            UPDATE intake_sessions
            SET data_json = $1, updated_at = CURRENT_TIMESTAMP
            WHERE id = $2 AND tenant_id = $3 AND status IN ('IN_PROGRESS', 'NEEDS_EDITS')
            RETURNING id
        `, [data, req.params.id, req.clinic.id]);

        if (result.rows.length === 0) return res.status(404).json({ error: 'Session not found or locked' });
        res.json({ success: true });
    } catch (error) {
        console.error('[Intake] Save failed:', error);
        res.status(500).json({ error: 'Failed' });
    }
});

/**
 * POST /public/submit/:id
 */
router.post('/public/submit/:id', async (req, res) => {
    try {
        const { data, signature } = req.body;

        const sessionRes = await pool.query(`
            SELECT prefill_json FROM intake_sessions WHERE id = $1 AND tenant_id = $2
        `, [req.params.id, req.clinic.id]);

        if (sessionRes.rows.length === 0) return res.status(404).json({ error: 'Not found' });
        const prefill = sessionRes.rows[0].prefill_json;

        const ipAddress = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;
        const userAgent = req.headers['user-agent'];

        const result = await pool.query(`
            UPDATE intake_sessions
            SET data_json = $1, 
                signature_json = $2, 
                status = 'SUBMITTED',
                submitted_at = CURRENT_TIMESTAMP,
                updated_at = CURRENT_TIMESTAMP,
                ip_address = $3,
                user_agent = $4
            WHERE id = $5 AND tenant_id = $6 AND status IN ('IN_PROGRESS', 'NEEDS_EDITS', 'SUBMITTED')
        `, [data, signature, ipAddress, userAgent, req.params.id, req.clinic.id]);

        if (result.rowCount === 0) return res.status(400).json({ error: 'Session locked or not found' });

        // Create Inbox Item
        const patientName = `${prefill.firstName} ${prefill.lastName}`;
        await pool.query(`
            INSERT INTO inbox_items (
                tenant_id, type, subject, body, reference_id, reference_table, status, priority
            ) VALUES ($1, $2, $3, $4, $5, 'intake_sessions', 'new', 'normal')
        `, [
            req.clinic.id,
            'new_patient_registration',
            `Registration: ${patientName}`,
            `Universal QR registration submitted. DOB: ${prefill.dob}. Phone: ${prefill.phone}`,
            req.params.id
        ]);

        await logIntakeAudit(pool, req.clinic.id, 'patient', null, 'submit', 'intake_sessions', req.params.id, req);

        res.json({ success: true });
    } catch (error) {
        console.error('[Intake] Submit failed:', error);
        res.status(500).json({ error: 'Failed' });
    }
});

module.exports = router;

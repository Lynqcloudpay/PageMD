import{r as n,t as s,e as o}from"./index-Rpa4WfhY.js";function i(e,r){n(2,arguments);var t=s(e),a=o(r);return isNaN(a)?new Date(NaN):(a&&t.setDate(t.getDate()+a),t)}export{i as a};

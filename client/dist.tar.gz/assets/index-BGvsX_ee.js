import{r as a,t as s}from"./index-cRF4l8VV.js";function o(t){a(1,arguments);var r=s(t);return r.setHours(0,0,0,0),r}export{o as s};

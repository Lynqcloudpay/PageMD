var s=6e4,n=36e5,a=1e3;export{s as a,a as b,n as m};

# Public Assets Folder

Place your PageMD logo image file here as `logo.png`.

The logo should be:
- PNG format (or JPG/JPEG if you prefer - then update the references from `/logo.png` to `/logo.jpg`)
- Recommended size: 200-400px wide (height will scale proportionally)
- Transparent background preferred

Supported formats:
- PNG (recommended)
- JPG/JPEG
- SVG

After placing the logo file, restart the development server if it's running.








